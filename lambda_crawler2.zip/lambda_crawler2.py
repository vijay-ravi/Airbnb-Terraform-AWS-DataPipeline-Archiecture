import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')
glue = boto3.client('glue')


def lambda_handler(event, context):
    try:
        glue.create_crawler(
            Name='final-crawler',
            Role = 'glues3accessrole',
            DatabaseName = 'Airbnb',
            Description = 'Crawler for crawling the final partitioned bucket',
            Targets = {
                'S3Targets': [
                    {
                        'Path': 's3://processed-bucket-5282020/airbnb-part'
                    }
                ]
            }
        )
        glue.start_crawler(Name='final-crawler')
    except Exception as e:
         if 'AlreadyExistsException' in str(e):
             glue.start_crawler(Name='final-crawler')
         else:
             raise e
