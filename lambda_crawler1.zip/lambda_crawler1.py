import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')
glue = boto3.client('glue')


def lambda_handler(event, context):
    try:
        glue.create_crawler(
            Name = "raw-crawler",
            Role = 'glues3accessrole',
            DatabaseName = 'Airbnb',
            Description = 'Crawler for crawling the raw data',
            Targets = {
                'S3Targets': [
                    {
                        'Path': 's3://raw-bucket-5282020'
                    }
                ]
            }
        )
        glue.start_crawler(Name='raw-crawler')
    except Exception as e:
         if 'AlreadyExistsException' in str(e):
             glue.start_crawler(Name='raw-crawler')
         else:
             raise e
