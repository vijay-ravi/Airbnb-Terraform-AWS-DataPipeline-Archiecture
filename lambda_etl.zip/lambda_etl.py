import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')
glue = boto3.client('glue')


def lambda_handler(event, context):
    try:
        glue.create_job(
            Name = 'Airbnb-partition-job',
            Description = 'Glue job to partition the airbnb data',
            Role = 'glues3accessrole',
            Command={
                'Name': 'glueetl',
                'ScriptLocation': 's3://script-bucket-5282020/etl_script.py',
                'PythonVersion': '3'
                },
            DefaultArguments={
                '--TempDir': 's3://temp-bucket-5282020/temp', '--job-bookmark-option': 'job-bookmark-disable'
            },
            MaxCapacity = 5,
            GlueVersion = '1.0',
            Timeout = 100
        )
        glue.start_job_run(
            JobName = 'Airbnb-partition-job'
        )
    except Exception as e:
         if 'AlreadyExistsException' in str(e):
             glue.start_job_run(
                JobName = 'Airbnb-partition-job'
            )
         elif 'IdempotentParameterMismatchException' in str(e):
             glue.start_job_run(
                JobName = 'Airbnb-partition-job'
            )
         else:
             raise e
