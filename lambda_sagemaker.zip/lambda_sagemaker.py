import json
import urllib.parse
import boto3

print('Loading function')
sage = boto3.client('sagemaker')

def lambda_handler(event, context):
    try:
        sage.create_notebook_instance(
            NotebookInstanceName = 'airbnb-analyis-nb',
            InstanceType='ml.t2.medium',
            RoleArn='arn:aws:iam::919359105948:role/sagemaker_service_role'
        )
    except Exception as e:
        print(e)
        raise e
